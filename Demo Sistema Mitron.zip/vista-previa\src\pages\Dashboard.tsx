
import { StatCard } from '../components/ui/Card';

export default function Dashboard() {
  const showMockAlert = () => alert('Acción de interfaz visual. Sin conexión a backend.');

  return (
    <div>
      <div className="mt-page-header">
        <div>
          <h1 className="mt-page-title">Dashboard</h1>
          <p className="mt-page-subtitle">Resumen general de actividad</p>
        </div>
      </div>
      <div className="mt-stats-grid">
        <StatCard title="Ingresos" value="$58,000.00" caption="Mes actual" />
        <StatCard title="Gastos" value="$0.00" caption="Sin otros gastos" />
        <StatCard title="Compras" value="$10,000.00" caption="Mes actual" />
        <StatCard title="Estado de Inventario" value="1" caption="Producto con stock bajo" />
      </div>
      
      <div className="mt-dashboard-columns">
        <div className="mt-panel">
          <div className="mt-panel-header">
            <h3 className="mt-panel-title">Evolución</h3>
            <button className="mt-panel-action" onClick={showMockAlert}>Filtrar</button>
          </div>
          <div style={{ padding: '16px', display: 'flex', alignItems: 'flex-end', height: '155px', gap: '8px', opacity: 0.7 }}>
             {/* Gráfica simulada con CSS */}
             <div style={{ flex: 1, backgroundColor: 'var(--mt-border)', height: '40%', borderRadius: '4px 4px 0 0' }}></div>
             <div style={{ flex: 1, backgroundColor: 'var(--mt-border)', height: '60%', borderRadius: '4px 4px 0 0' }}></div>
             <div style={{ flex: 1, backgroundColor: '#7CE38B', height: '90%', borderRadius: '4px 4px 0 0' }}></div>
             <div style={{ flex: 1, backgroundColor: 'var(--mt-border)', height: '70%', borderRadius: '4px 4px 0 0' }}></div>
             <div style={{ flex: 1, backgroundColor: 'var(--mt-border)', height: '50%', borderRadius: '4px 4px 0 0' }}></div>
          </div>
          <div style={{ textAlign: 'center', fontSize: '11px', color: 'var(--mt-text-secondary)', padding: '8px' }}>Gráfica de ejemplo visual</div>
        </div>
        <div className="mt-panel">
          <div className="mt-panel-header">
            <h3 className="mt-panel-title">Actividad Reciente</h3>
          </div>
          <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ fontSize: '12px' }}>
              <span style={{ color: '#7CE38B', marginRight: '8px' }}>●</span>
              Ventas mes actual importadas
              <div style={{ color: 'var(--mt-text-secondary)', fontSize: '11px', marginLeft: '16px', marginTop: '2px' }}>Hace 2 horas</div>
            </div>
            <div style={{ fontSize: '12px' }}>
              <span style={{ color: '#E5A93C', marginRight: '8px' }}>●</span>
              Límite de stock actualizado (PROD-001)
              <div style={{ color: 'var(--mt-text-secondary)', fontSize: '11px', marginLeft: '16px', marginTop: '2px' }}>Ayer</div>
            </div>
            <div style={{ fontSize: '12px' }}>
              <span style={{ color: 'var(--mt-text-primary)', marginRight: '8px' }}>●</span>
              Nuevo proveedor registrado
              <div style={{ color: 'var(--mt-text-secondary)', fontSize: '11px', marginLeft: '16px', marginTop: '2px' }}>Hace 3 días</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
